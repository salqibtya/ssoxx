# Contributor Guidelines

Please see the [Contributor Guidelines](http://apereo.github.io/cas/developer/Contributor-Guidelines.html) for more info.
