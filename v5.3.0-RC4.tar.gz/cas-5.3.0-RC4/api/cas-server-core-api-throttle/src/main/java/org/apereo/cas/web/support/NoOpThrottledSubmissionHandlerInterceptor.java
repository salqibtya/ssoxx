package org.apereo.cas.web.support;

/**
 * This is {@link NoOpThrottledSubmissionHandlerInterceptor}.
 *
 * @author Misagh Moayyed
 * @since 5.3.0
 */
public class NoOpThrottledSubmissionHandlerInterceptor implements ThrottledSubmissionHandlerInterceptor {
}
